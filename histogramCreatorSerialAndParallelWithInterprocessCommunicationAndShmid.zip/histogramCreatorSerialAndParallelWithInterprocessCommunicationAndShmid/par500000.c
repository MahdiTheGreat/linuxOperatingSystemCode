#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>


int main(){

int master[500000];
clock_t begin = clock();




for(int k=0;k<20000;k++){

pid_t child_pid, wpid;
int status = 0;

key_t key =(random() %
           (10000 - 0 + 1)) + 0;

int *a;
int shmid = shmget(key, 25*sizeof(int), IPC_CREAT);
a= shmat(shmid, NULL,  0);

for(int h=0;h<25;h++){

a[h]=0;
}

int *b[5];


for (int id=0; id<5; id++) {
    
    
    
   
    if ((child_pid = fork()) == 0) {
    srandom(time(NULL)*id);
    int shmid2 = shmget(key, 25*sizeof(int), IPC_EXCL);
    b[id]= shmat(shmid2, NULL,  0);
   
    for (int i = id*5; i < id*5+5; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)b[id][i]++;
        else b[id][i]--;
        }
    }
    exit(0);
        
       
    }



}

while ((wpid = wait(&status)) > 0);
int f=0;
for(int l=25*k;l<25*k+25;l++){
master[l]=a[f];
f++;
}

for(int h=0;h<25;h++){
a[h]=0;
}

shmdt((void *) a);

}
clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("the time of executuion is %0f",time_spent);
for(int i=56000;i<56100;i++){
     printf(" %d", master[i]);
}
}


