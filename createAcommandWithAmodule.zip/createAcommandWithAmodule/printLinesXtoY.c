#include <stdio.h> 
#include <stdlib.h> 
  

  
int main() 
{ 
    char add[50];
    char buffer[1000];
    printf(" please the address of file\n");
    scanf("%s",add);
    
    int x,y;
    printf(" please the parameters\n");
    scanf("%d %d", &x,&y);
   FILE *fptr;
   fptr = fopen(add,"r+");
   if(fptr == NULL)
   {
      printf("Error!");   
      exit(1);             
   }
   else{
   char c=NULL;
   int temp=0;
      while((feof(fptr)==0) && (temp!=(x))){
          c=(char) fgetc(fptr);
          if(c=='\n')temp=temp+1;
      }
      int temp2=0;
      int i=0;
      while((feof(fptr)==0) && (temp2!=(y-x))){
          c=(char)fgetc(fptr);
          buffer[i]=c;
          i=i+1;
          if(c=='\n')temp2=temp2+1;
          
      }
      
   }
   
   
   
   
   printf(buffer);
   
    
    
    
  
    

return 0;
}
