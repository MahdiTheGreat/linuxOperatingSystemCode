#include </usr/src/linux-headers-5.0.0-37/include/linux/kernel.h>
#include </usr/src/linux-headers-5.0.0-37/include/linux/module.h>
#include </usr/src/linux-headers-5.0.0-37/include/linux/compiler.h>
#include </usr/src/linux-headers-5.0.0-37/include/linux/list.h>
#include </usr/src/linux-headers-5.0.0-37/include/linux/types.h>
#include </usr/src/linux-headers-5.0.0-37/include/linux/slab.h>

struct birthday {
    int day;
    int month;
    int year;
    struct list_head list;
};

static LIST_HEAD(birthday_list);

int simple_init(void) {
    struct birthday *ptr;
    int i;
    for(i = 0; i < 6; i++) {
        // create 5 birthday structs and add them to the list

        struct birthday *person;
        person = kmalloc(sizeof(*person), GFP_KERNEL);
        person->day = 22;
        person->month = 11;
        person->year = 1981;
        INIT_LIST_HEAD(&person->list);

        list_add_tail(&person->list, &birthday_list);
    }

    list_for_each_entry(ptr, &birthday_list, list) {
        // print the info from the structs to the log
        printk(KERN_INFO "%d, %d %d", ptr->month, ptr->day, ptr->year);
    }

    return 0;
}


void simple_exit(void) {
    struct birthday *ptr, *next;
    list_for_each_entry_safe(ptr, next, &birthday_list, list) {
        // delete structs and return memory
        list_del(&ptr->list);
        kfree(ptr);
    }
}

module_init(simple_init);
module_exit(simple_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("simple lonked list");
MODULE_AUTHOR("sgg");
