#include <stdio.h> 
#include <stdlib.h> 
  
int main()
{
    char str[100];
    char toSearch;
    int i, count;

    
    printf("enter the string: ");
    gets(str);
    printf("Enter the char to search for: ");
    toSearch = getchar();

    count = 0;
    i=0;
    while(str[i] != '\0')
    {
       
        if(str[i] == toSearch)
        {
            count++;
        }

        i++;
    }

    printf("the character has apeared  %d times", count);

    return 0;
}
