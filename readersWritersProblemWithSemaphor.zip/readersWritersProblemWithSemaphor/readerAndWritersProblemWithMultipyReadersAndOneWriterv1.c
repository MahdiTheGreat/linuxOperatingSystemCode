#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 
int main(){


//semaphore rw_mutex= 1;
//semaphore mutex= 1;
sem_t mutex;
sem_t rw_mutex;
sem_init(&mutex, 1, 1); 
sem_init(&rw_mutex, 1, 1); 
pid_t child_pid, wpid;
int *buffer;
int *read_count;
key_t key = 10050;
key_t key2 =20050;
const int max=5;

int shmid = shmget(key, sizeof(int), IPC_CREAT);
buffer= shmat(shmid, NULL,  0);
*buffer=0;

int shmid2 = shmget(key, sizeof(int), IPC_CREAT);
read_count= shmat(shmid, NULL,  0);
*read_count=0;

for (int id=0; id<2; id++) {
if ((child_pid = fork()) == 0) {
int doneRead=0;
child_pid=getpid();
int shmid3 = shmget(key, sizeof(int), IPC_EXCL);
int *bufferr= shmat(shmid, NULL,  0);
int shmid4 = shmget(key, sizeof(int), IPC_EXCL);
int *read_count2= shmat(shmid, NULL,  0);

do {
if(*bufferr>0){
printf("bufferr value is %d \n",*bufferr);
sem_wait(&mutex);
*read_count2++;
if (*read_count== 1)sem_wait(&rw_mutex);
sem_post(&mutex);


doneRead+=1;
*bufferr-=1;

printf("reading is performed and buffer size is %d and pid is %d \n ",*bufferr,child_pid);
sem_wait(&mutex);
*read_count2--;
if (*read_count2== 0)
sem_post(&rw_mutex);
sem_post(&mutex);
}
} while (doneRead<4);

exit(0);
}
}

int doneWrite=0;
do {
if(*buffer<max){
wpid=getpid();
sem_wait(&rw_mutex);
printf("bufferr value is %d \n",*buffer);
doneWrite+=1;
*buffer+=1;
printf("writing is performed and buffer size is %d and pid is %d \n ",*buffer,wpid);
sem_post(&rw_mutex);
}
} while (doneWrite<8);

}

