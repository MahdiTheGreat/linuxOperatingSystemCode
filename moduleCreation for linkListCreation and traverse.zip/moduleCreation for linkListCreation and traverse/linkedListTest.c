#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
struct birthday {
int day;
int month;
int year;
struct list_head list;
};

static LIST_HEAD(birthday_list);

int simple_init() 
{ 
printk(KERN_INFO "making Linkedlist\n");
//struct birthday birthdays[4];
for (i=0;i<5;i++){
struct birthday *person;
person = kmalloc(sizeof(person), GFP_KERNEL);
person->day = i;
person->month = i;
person->year = i*1000;
INIT_LIST_HEAD(&person->list);
list_add_tail(&person->list, &birthday_list);
}
struct birthday *ptr;
list_for_each_entry(ptr, &birthday_list,list){
    printk(KERN_INFO "day:%d, month:%d, year: %d\n",
    ptr->day,
    ptr->month,
    ptr->year);
    }
 return 0;

}

int simple_exit(){
	printk(KERN_INFO "destorying linkedlist\n");

    struct birthday *ptr, *next;

    list_for_each_entry_safe(ptr,next,&birthday_list, list){
    printk(KERN_INFO "day:%d, month:%d, year: %d\n",
    ptr->day,
    ptr->month,
    ptr->year);
    list_del(&ptr->list);
    kfree(ptr);
	}
	printk(KERN_INFO "checking for destruction\n");
	list_for_each_entry(ptr, &birthday_list,list){
    printk(KERN_INFO "day:%d, month:%d, year: %d\n",
    ptr->day,
    ptr->month,
    ptr->year);
    }
	return 0;
    }
module_init( simple_init );
module_exit( simple_exit );

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("linkedlist tester");
MODULE_AUTHOR("mahdi");
	
	
	
	
	
	


 
