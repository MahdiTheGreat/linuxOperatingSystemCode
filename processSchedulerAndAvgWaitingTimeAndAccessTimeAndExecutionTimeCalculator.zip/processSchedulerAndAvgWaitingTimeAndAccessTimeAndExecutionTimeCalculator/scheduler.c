/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdbool.h>

struct process
{
    int pid;
    bool flag;
    int priority;
    int bt;
    int wt,tt;
};

int * average(struct process p[],int pn){
    int ttSum,wtSum=0;
    int averages[2];
    for(int i=0;i<pn;i++){
        ttSum+=p[i].tt;
        wtSum+=p[i].wt;
    }
    averages[1]=ttSum/pn;
    averages[0]=wtSum/pn;
    return averages;

}




void swap(struct process *xp, struct process *yp)
{
    struct process temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void selectionSort(struct process arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
            if (arr[j].bt < arr[min_idx].bt)
                min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }
}

void selectionSortPriority(struct process arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
            if (arr[j].priority < arr[min_idx].priority)
                min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }
}

bool flagChecker(struct process p[],int pn){
    bool flag=true;
    for(int i=0;i<pn;i++){
        if(p[i].flag==false)flag=false;
    }
    return flag;

}


void fcfs(struct process p[],int pn){


    int wt=0;
    int temp=0;

    while(flagChecker(p,pn)){

        for(int i=0;i<pn;i++){
            if(p[i].flag==false){

                temp=wt;
                wt+=p[i].bt;
                p[i].wt=temp;
                p[i].tt=wt;
                p[i].flag=true;



            }
        }

    }

}

void sjf(struct process p[],int pn){
    selectionSort(p,pn);
    fcfs(p,pn);

}

void priority(struct process p[],int pn){
    selectionSortPriority(p,pn);
    fcfs(p,pn);

}

void roundRobin(struct process p[],int pn,int q){


    int wt=0;
    int temp=0;

    while(flagChecker(p,pn)){

        for(int i=0;i<pn;i++){
            if(p[i].flag==false){

                temp=wt;
                wt+=q;
                p[i].bt-=q;

                if(p[i].bt<=0){
                    p[i].wt=temp;
                    p[i].tt=temp+p[i].bt;
                    p[i].flag=true;
                }



            }
        }

    }

}

void initialise(struct process p[],int pn,int mode){
    for(int i=0;i<pn;i++){
        p[i].flag=false;
        p[i].wt=0;
        p[i].tt=0;
    }
    if(mode){
        for(int i=0;i<pn;i++){
            p[i].pid=i;
        }
    }
}

int main()
{
    int pn;
    int q;
    int averages[4][2];
//int bt;

    printf("please enter the number of processes and quantum");
    scanf("%d %d",&pn,&q);

    struct process p[pn];



    initialise(p,pn,1);

    printf("enter the bt and priority for each process") ;
    for(int i=0;i<pn;i++){
        printf("enter \n");
        scanf("%d %d",&p[i].bt,&p[i].priority);

    }

    for(int i=0;i<4;i++){
        int * temp;
        switch(i) {

            case 0  :
                fcfs(p,pn);
                temp=average(p,pn);
                break; /* optional */

            case 1  :
                sjf(p,pn);
                temp=average(p,pn);
                break; /* optional */

            case 2  :
                priority(p,pn);
                temp=average(p,pn);
                break; /* optional */

            case 3  :
                roundRobin(p,pn,q);
                temp=average(p,pn);
                break; /* optional */
        }

        averages[i]=temp;
        initialise(p,pn,0);

    }






}

