#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

int main(){
srandom(time(NULL));
int a[5000];
clock_t begin = clock();


for(int k=0;k<5000;k++){
a[k]=0;
}

for (int i =0; i < 5000 ;i++) {
       
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
    }
}


clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("the time of executuion is %0f",time_spent);

for(int i=25;i<125;i++){
     printf(" %d", a[i]);
}
}


