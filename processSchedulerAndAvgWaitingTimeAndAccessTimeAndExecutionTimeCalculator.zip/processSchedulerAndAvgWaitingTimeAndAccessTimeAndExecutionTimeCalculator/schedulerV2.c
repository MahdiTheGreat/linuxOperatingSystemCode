/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdbool.h>

struct process
{
int pid;
bool flag;
int priority;
int bt;
int wt,tt;
int lastTouch;
};

void average(float temp[],struct process p[],int pn){
    float ttSum,wtSum=0;
    for(int i=0;i<pn;i++){
    ttSum+=p[i].tt;
    wtSum+=p[i].wt;
    }
    temp[1]=ttSum/pn;
    temp[0]=wtSum/pn;


}

void printer(struct process p[],int pn){
    for(int i=0;i<pn;i++){
    printf("%d",p[i].pid);
    }
    printf("\n");
}

void printerWt(struct process p[],int pn){

    printf("the wt of processes are with their pids\n");
    for(int i=0;i<pn;i++){

        printf("%d %d \n",p[i].wt,p[i].pid);
    }
    printf("\n");
}

void printertt(struct process p[],int pn){
    printf("the tt of processes are with their pids\n");
    for(int i=0;i<pn;i++){

        printf("%d %d \n",p[i].tt,p[i].pid);
    }
    printf("\n");
}





void swap(struct process *xp, struct process *yp)
{
    struct process temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void selectionSort(struct process arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
        if (arr[j].bt < arr[min_idx].bt)
            min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }

    //printf("after selectionSort");
    //printer(arr,n);
}

void selectionSortPriority(struct process arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
        if (arr[j].priority < arr[min_idx].priority)
            min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }
    //printf("after selectionSortPriority");
    //printer(arr,n);
}

void selectionSortId(struct process arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
            if (arr[j].pid < arr[min_idx].pid)
                min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }

    //printf("after selectionSort");
   // printer(arr,n);
}

bool flagChecker(struct process p[],int pn){
bool flag=false;
for(int i=0;i<pn;i++){
    if(p[i].flag==false)flag=true;
}
return flag;

}


void fcfs(struct process p[],int pn){


    int wt=0;
    int temp=0;

    while(flagChecker(p,pn)){

        for(int i=0;i<pn;i++){
        if(p[i].flag==false){

            temp=wt;
            wt+=p[i].bt;
            p[i].wt=temp;
            p[i].tt=wt;
            p[i].flag=true;



        }
        }

    }

}

void sjf(struct process p[],int pn){
    selectionSort(p,pn);
    fcfs(p,pn);

}

void priority(struct process p[],int pn){
    selectionSortPriority(p,pn);
    fcfs(p,pn);

}

void roundRobin(struct process p[],int pn,int q){


    int wt=0;
    int temp=0;
    int temp2=0;
    struct process* p1=p;


    while(flagChecker(p,pn)){

        for(int i=0;i<pn;i++){
        if(p[i].flag==false){

            //temp=wt;
            temp2=p[i].bt-q;
            p[i].wt+=wt-p[i].lastTouch;
            if(temp2<=0){
                p[i].tt=p[i].wt+p1[i].bt;
                wt+=p[i].bt;
                p[i].flag=true;
            }
            else{
                wt+=q;
                p[i].bt-=q;
                p[i].lastTouch=wt;
            }
           // printf("the wt and lasttouch of %d is %d %d\n",i,p[i].wt,p[i].lastTouch);
            //printf("wt is %d \n",wt);



        }
        }

    }

}

void initialise(struct process p[],int pn,int mode){
    for(int i=0;i<pn;i++){
    p[i].flag=false;
    p[i].wt=0;
    p[i].tt=0;
    p[i].lastTouch=0;
    }
    if(mode){
      for(int i=0;i<pn;i++){
      p[i].pid=i;
      }
    }
}

int main()
{
int pn;
int q;
//int bt;

printf("please enter the number of processes and quantum");
scanf("%d %d",&pn,&q);

struct process p[pn];



initialise(p,pn,1);

//printf("after initialise");
//printer(p,pn);

printf("enter the bt and priority for each process") ;
for(int i=0;i<pn;i++){
    printf("enter \n");
    scanf("%d %d",&p[i].bt,&p[i].priority);

}

for(int i=0;i<4;i++){
    float temp[2];
    switch(i) {

   case 0  :
       printf("in the fcfs schechuling the wt and tt are\n");
      fcfs(p,pn);
      average(temp,p,pn);
      printf("%f %f \n",temp[0],temp[1]);
      printerWt(p,pn);
      printertt(p,pn);
      break; /* optional */

   case 1  :
       printf("in the sjf schechuling the wt and tt are\n");
      sjf(p,pn);
      average(temp,p,pn);
      printf("%f %f \n",temp[0],temp[1]);
      printerWt(p,pn);
      printertt(p,pn);
      break; /* optional */

   case 2  :
       printf("in the priority schechuling the wt and tt are\n");
      priority(p,pn);
      average(temp,p,pn);
      printf("%f %f \n",temp[0],temp[1]);
      printerWt(p,pn);
      printertt(p,pn);
      selectionSortId(p,pn);
    break; /* optional */

     case 3  :
         printf("in the roundrobin schechuling the wt and tt are\n");
      roundRobin(p,pn,q);
     average(temp,p,pn);
      printf("%f %f \n",temp[0],temp[1]);
      printerWt(p,pn);
      printertt(p,pn);
      break; /* optional */
  }


  initialise(p,pn,0);

}






}


