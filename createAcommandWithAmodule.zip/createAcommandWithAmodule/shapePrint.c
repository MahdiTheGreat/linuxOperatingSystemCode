#include <stdio.h> 
#include <stdlib.h> 
  

  
int main() 
{
    
    
    int n;
    
    
    
    printf(" please enter height\n");
    
    scanf("%d",&n);
    
    for(int i=0;i<n;i++){
        
        for (int j=i+1;j>0;j--){
            printf("#");
        }
        printf(" ");
        for (int j=i+1;j>0;j--){
            printf("#");
        }
        printf("\n");
        
    }
    
    
   
    
    
    
  
    

return 0;
}
