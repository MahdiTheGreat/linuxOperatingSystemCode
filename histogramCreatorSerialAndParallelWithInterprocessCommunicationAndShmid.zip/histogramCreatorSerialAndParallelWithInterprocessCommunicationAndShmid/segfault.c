#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <time.h>

void printHistogram(int *hist) {
int i, j;
for (i = 0; i < 25; i++) {
for (j = 0; j < hist[i]; j++) {
printf("*");
}
printf("\n");
}
}

int main(){

pid_t child_pid, wpid;
int status = 0;
int *a;
key_t key = 12345;

int shmid = shmget(key, 50*sizeof(int), IPC_CREAT);
a= shmat(shmid, NULL,  0);
srandom(time(NULL));
clock_t begin = clock();

int *b[5];


for (int id=0; id<5; id++) {
    if ((child_pid = fork()) == 0) {
    
    shmid = shmget(key, 50*sizeof(int), IPC_EXCL);
    b[id]= shmat(shmid, NULL,  0);
   
    for (int i = id*10; i < id*10+10; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)b[id][i]++;
        else b[id][i]--;
        }
    }
        
        exit(0);
    }
}

while ((wpid = wait(&status)) > 0);
clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("the time of executuion is %0f",time_spent);
printHistogram(a);


}



