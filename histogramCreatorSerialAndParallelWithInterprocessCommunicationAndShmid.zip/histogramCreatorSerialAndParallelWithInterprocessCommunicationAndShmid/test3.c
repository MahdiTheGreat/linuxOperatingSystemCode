#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>




int main(){
int *a;
key_t key = 12345;
shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
a= shmat(shmid, NULL,  SHM_EXEC);

clock_t begin = clock();




for(int i=0;i<25;i++){
      a[i]=0;
}

int process_1;
int process_2;
int process_3;
int process_4;
int process_5;

pid_t pid = fork();
if (pid) {
    process_1 = pid;
    pid = fork();
}
if (pid) {
    process_2 = pid;
    pid = fork();
}
if (pid) {
    process_3 = pid;
    pid = fork();
}
if (pid){
    process_4 = pid;
    pid = fork();
}
if (pid)process_5 = pid;
   


if(process_1 == 0){
   
    for (int i = 0; i < 5; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
        }
    }
}
if(process_2 == 0){
   
    for (int i = 5; i < 10; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
        }
    }
}
if(process_3 == 0){
   
    for (int i = 10; i < 15; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
        }
    }
}
if(process_4 == 0){
   
    for (int i = 15; i < 20; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
        }
    }
}
if(process_5 == 0){
   
    for (int i = 20; i < 25; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a[i]++;
        else a[i]--;
        }
    }
}

if(pid){
wait(NULL);
clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("the time of executuion is %0f",time_spent);
for(int i=0;i<25;i++){
      printf(" %d", a[i]);
}
}



}
