#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 








//pid_t child_pid, wpid;
//int *buffer;

const key_t key = 123456;
const int max=10;
int shmid;





void EndRead (sem_t write,sem_t mutex)
{

pid_t child_pid=getpid();

sem_wait(&mutex);

int *buffer= shmat(shmid, NULL,  0);

buffer[1]--;

if(buffer[0]>0)buffer[0]--;
sem_post(&mutex);

printf("reading is performed and buffer size is %d and pid is %d \n ",buffer[0],child_pid);


if (buffer[1] == 0 ) sem_post(&write);

}

void EndWrite (sem_t write,sem_t read,sem_t mutex)
{

pid_t wpid=getpid();

sem_wait(&mutex);

int *buffer= shmat(shmid, NULL,  0);

buffer[2]=0;

if(buffer[0]<max)buffer[0]++;

sem_post(&mutex);

printf("writing is performed and buffer size is %d and pid is %d \n ",buffer[0],wpid);


if (buffer[3] > 0 )sem_post(&read);
else sem_post(&write);
}

void BeginRead(sem_t read)
{

int *buffer= shmat(shmid, NULL,  0);

if (buffer[2] == 1 || buffer[4] > 0)
{
buffer[3]+= 1;
sem_wait(&read);
buffer[3] += 1;
}
buffer[1] += 1;
sem_post(&read);
}

void BeginWrite(sem_t write)
{


int *buffer= shmat(shmid, NULL,  0);

if (buffer[2] == 1 || buffer[1] > 0)
{
buffer[4] += 1;
sem_wait(&write);
buffer[4] += 1;
}
buffer[2] = 1;
}

int main(){

shmid = shmget(key, 5*sizeof(int), IPC_CREAT);
int *buffer= shmat(shmid, NULL,  0);

for (int i=0; i<5; i++) {
buffer[i]=0;
}


printf("begining main program\n ");
sem_t write;
sem_t read;
sem_t mutex;
int status = 0;
sem_init(&write, 1, 1); 
sem_init(&read, 1, 1);
sem_init(&mutex, 1, 1);
pid_t child_pid, wpid; 

for (int id=0; id<4; id++) {
if((id%2)==0){
if ((child_pid = fork()) == 0) {
//printf("child succesful\n ");

int doneWrite=5;
do {
BeginWrite( write);
EndWrite(write,read,mutex);
doneWrite--;
}while(doneWrite>0);
exit(0);
}
}
else{
if ((child_pid = fork()) == 0) {
int doneRead=5;
do {
BeginRead(read);
EndRead(write,mutex);
doneRead--;
}while(doneRead>0);
exit(0);
} 
}

    
}



while ((wpid = wait(&status)) > 0);
printf("done\n ");
return 0;

}



