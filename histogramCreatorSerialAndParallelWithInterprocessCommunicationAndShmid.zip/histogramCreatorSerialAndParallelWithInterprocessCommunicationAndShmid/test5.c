#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>




int main(){
int *a;
key_t key = 12345;

int shmid = shmget(key, 25*sizeof(int), IPC_CREAT);
a= shmat(shmid, NULL,  0);
int status=0;
int status1=0;
int status2=0;
int status3=0;
int status4=0;
int status5=0;
srandom(777);

clock_t begin = clock();




for(int i=0;i<25;i++){
      a[i]=0;
}

int process_1;
int process_2;
int process_3;
int process_4;
int process_5;
pid_t temp;
pid_t temp1;
pid_t temp2;
pid_t temp3;
pid_t temp4;
pid_t temp5;

pid_t pid = fork();

if (pid) {
    temp1=pid;
    process_1 = pid;
    pid = fork();
}
if (pid) {
    temp2=pid;
    
    process_2 = pid;
    pid = fork();
}
if (pid) {
    temp3=pid;
    process_3 = pid;
    pid = fork();
}
if (pid){
    temp4=pid;
    process_4 = pid;
    pid = fork();
}
if (pid){
temp5=pid;
process_5 = pid;
}
   


if(process_1 == 0){
    printf("process1");
    int *a1;
    shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
    a1= shmat(shmid, NULL,  0);
   
    for (int i = 0; i < 5; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a1[i]++;
        else a1[i]--;
        }
    }
exit(0);
}
if(process_2 == 0){
    printf("process2");
    int *a2;
    shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
    a2= shmat(shmid, NULL,  0);
   
    for (int i = 5; i < 10; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a2[i]++;
        else a2[i]--;
        }
    }
 exit(0);
}

if(process_4 == 0){
   int *a4;
   printf("process 4 i");
    shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
    a4= shmat(shmid, NULL,  0);
    for (int i = 15; i < 20; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a4[i]++;
        else a4[i]--;
        }
    }
exit(0);
}

if(process_3 == 0){
   int *a3;
   printf("process 3");
    shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
    a3= shmat(shmid, NULL,  0);
    for (int i = 10; i < 15; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a3[i]++;
        else a3[i]--;
        }
    }
exit(0);
}



if(process_5 == 0){
    int *a5;
    printf("process 5 ");
    shmid = shmget(key, 25*sizeof(int), IPC_EXCL);
    a5= shmat(shmid, NULL,  0);
   
    for (int i = 20; i < 25; i++) {
        for(int j=0;j<12;j++ ){
        int num = (random() %
           (100 - 0 + 1)) + 0;
        if(num>=45)a5[i]++;
        else a5[i]--;
        }
    }
exit(0);
}

if(pid){
waitpid(temp1,&status1,0);
waitpid(temp2,&status2,0);
waitpid(temp3,&status3,0);
waitpid(temp4,&status4,0);
waitpid(temp5,&status5,0);

clock_t end = clock();
double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf("the time of executuion is %0f",time_spent);
for(int i=0;i<25;i++){
      printf(" %d", a[i]);
}
}



}
