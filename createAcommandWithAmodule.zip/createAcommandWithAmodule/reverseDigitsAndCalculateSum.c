#include <stdio.h> 
#include <stdlib.h> 
  
struct Node { 
    int data; 
    struct Node* next; 
}; 
  

void printList(struct Node* n) 
{ 
    while (n != NULL) { 
        printf(" %d ", n->data); 
        n = n->next; 
    } 
} 
  
int main() 
{ 
    struct Node* head = NULL; 
    head = (struct Node*)malloc(sizeof(struct Node));
    printf(" please enter a number\n");
    int i;
    int a;
    int temp;
    scanf("%d", &i);
    head->data=i;
    while(i!=-1){
    
    struct Node* temp1=head;
    struct Node* temp2=head;
    while(temp1!=NULL){
        while(temp2!=NULL){
            
            if ((temp1->data) > (temp2->data))
            {

                a =  temp1->data;
                temp1->data= temp2->data;
               temp2->data = a;

            }
          
        temp2=temp2->next;    
        
    }
      temp1=temp1->next;
    }
    printList(head);
    printf(" \n");
    temp=0;
    struct Node* temp3=head;
    while(temp3!=NULL){
        
    
            
    temp=temp+temp3->data;
    temp3=temp3->next;
    }
    
    printf("the sum of numbers is \n");
    printf("%d\n", temp);
    
    printf(" please enter a number\n");
    scanf("%d", &i);
    struct Node* head2=(struct Node*)malloc(sizeof(struct Node));
    head2->data=i;
    head2->next=head;
    head=head2;
    
    
    
  
    
}
return 0;
}
